variable "hostname" {}
variable "ip" {}

resource "null_resource" "example" {
  provisioner "local-exec" {
    command = "echo building ${var.hostname} ${var.ip}"
  }
}