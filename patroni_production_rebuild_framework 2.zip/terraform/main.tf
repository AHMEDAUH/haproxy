terraform {
  required_version = ">=1.3"
}

module "node1" {
  source = "./modules/postgres_vm"
  hostname = "node1"
  ip = "10.0.0.11"
}

module "node2" {
  source = "./modules/postgres_vm"
  hostname = "node2"
  ip = "10.0.0.12"
}

module "node3" {
  source = "./modules/postgres_vm"
  hostname = "node3"
  ip = "10.0.0.13"
}