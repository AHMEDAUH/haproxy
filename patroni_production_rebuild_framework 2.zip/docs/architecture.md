# Architecture

Cluster Components

Patroni nodes
External etcd cluster
pgBackRest backup repository
Terraform infrastructure
Ansible automation

Rebuild Workflow

1 Prechecks
2 Remove node from Patroni cluster
3 Terraform destroy/apply
4 pgBackRest delta restore
5 Start Patroni
6 Verify streaming replication
7 Cluster validation

Order:

Replica -> Replica -> Switchover -> Old Leader

Never rebuild leader first.