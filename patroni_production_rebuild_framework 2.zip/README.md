# Patroni Cluster Node Rebuild Framework

Production-grade automation to rebuild Patroni PostgreSQL nodes safely.

Technologies:
- Patroni
- PostgreSQL
- pgBackRest
- Terraform
- Ansible
- External etcd
- RHEL 8 compatible

Features:
- Zero downtime rolling node rebuild
- Automatic safety checks
- Replication lag validation
- Terraform-based VM recreation
- pgBackRest delta restore
- Patroni cluster integrity checks
- Modular Ansible roles

Workflow:

1 Remove node from cluster
2 Terraform rebuild VM
3 Restore consistency
4 Rejoin node
5 Post cluster checks

See docs/architecture.md for details.