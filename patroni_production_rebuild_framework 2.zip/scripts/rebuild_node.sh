#!/bin/bash
set -e

NODE=$1

if [ -z "$NODE" ]; then
  echo "Usage: ./rebuild_node.sh <node>"
  exit 1
fi

echo "STEP 1 Remove node from cluster"
ansible-playbook -i ansible/inventory.ini ansible/remove_node.yml --limit $NODE

echo "STEP 2 Terraform rebuild"
cd terraform
terraform init
terraform destroy -target=module.$NODE -auto-approve
terraform apply -target=module.$NODE -auto-approve
cd ..

echo "STEP 3 Join node back"
ansible-playbook -i ansible/inventory.ini ansible/join_node.yml --limit $NODE

echo "Node rebuild complete"